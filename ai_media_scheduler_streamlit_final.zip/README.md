# AI Media Scheduler

A Streamlit app that allows users to:
- Upload audio, video, and PDF files
- Automatically rotate and play a file daily
- Use AI to summarize PDF documents
- Visualize playback progress with charts

👨‍🍳 Created by Chef Boss for the 3MTT AI Challenge.